package beemyapp.myapplication4;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.glass.widget.CardBuilder;
import com.google.android.glass.widget.CardScrollAdapter;
import com.google.android.glass.widget.CardScrollView;

import java.util.ArrayList;

/**
 * An {@link android.app.Activity} showing a tuggable "Hello World!" card.
 * <p>
 * The main content view is composed of a one-card {@link com.google.android.glass.widget.CardScrollView} that provides tugging
 * feedback to the user when swipe gestures are detected.
 * If your Glassware intends to intercept swipe gestures, you should set the content view directly
 * and use a {@link com.google.android.glass.touchpad.GestureDetector}.
 * @see <a href="https://developers.google.com/glass/develop/gdk/touch">GDK Developer Guide</a>
 */
public class InformationActivity extends Activity {

    /** {@link com.google.android.glass.widget.CardScrollView} to use as the main content view. */
    private CardScrollView mCardScroller;

    //private View mView;
    private ArrayList<View> views;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);

      //  mView = buildView();
        views = new ArrayList<View>();
        for (int i = 0;  i < 1; i++) {
            View view = buildView(i);
            views.add(view);
        }
        mCardScroller = new CardScrollView(this);
        mCardScroller.setAdapter(new CardScrollAdapter() {
            @Override
            public int getCount() {
                return views.size();
            }

            @Override
            public Object getItem(int position) {
                return views.get(position);
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return views.get(position);
            }

            @Override
            public int getPosition(Object item) {
                /*if (mView.equals(item)) */{
                    return 0;
                }
                //return AdapterView.INVALID_POSITION;
            }
        });
        setContentView(mCardScroller);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mCardScroller.activate();
    }

    @Override
    protected void onPause() {
        mCardScroller.deactivate();
        super.onPause();
    }

    /**
     * Builds a Glass styled "Hello World!" view using the {@link com.google.android.glass.widget.CardBuilder} class.
     */
    private View buildView(int position) {
        CardBuilder card = new CardBuilder(this, CardBuilder.Layout.CAPTION);

        int imageResource;
        switch (position) {
            default:
                imageResource = R.drawable.image_13;
                break;
        }
        card.addImage(getResources().getDrawable(imageResource));
        return card.getView();
    }

}
